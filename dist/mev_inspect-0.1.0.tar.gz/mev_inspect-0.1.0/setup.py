# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mev_inspect',
 'mev_inspect.classifiers',
 'mev_inspect.classifiers.specs',
 'mev_inspect.crud',
 'mev_inspect.models',
 'mev_inspect.schemas']

package_data = \
{'': ['*'],
 'mev_inspect': ['abis/*',
                 'abis/0x/*',
                 'abis/aave/*',
                 'abis/balancer_v1/*',
                 'abis/curve/*',
                 'abis/sushiswap/*',
                 'abis/uniswap_v2/*',
                 'abis/uniswap_v3/*',
                 'abis/weth/*']}

install_requires = \
['click>=8.0.1,<9.0.0',
 'hexbytes>=0.2.1,<0.3.0',
 'psycopg2>=2.9.1,<3.0.0',
 'pydantic>=1.8.2,<2.0.0',
 'web3>=5.23.0,<6.0.0']

entry_points = \
{'console_scripts': ['inspect-block = cli:inspect_block_command',
                     'inspect-many-blocks = cli:inspect_many_blocks_command']}

setup_kwargs = {
    'name': 'mev-inspect',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
